
<?php include('header.php')  ?>


<!--=================================
page-title-->

<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">Corporate Training</h1>
				</div>
			</div>
		 </div>
	</div>
</div>

<!--=================================
page-title -->







<!--=================================
 Corporate service-->
<section class="section-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-md-offset-2">
				<div class="section-title text-center">
					<p>We're Good At Corporate Training program</p>
				</div>      
			</div>
		</div>
		
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="feature-text box-shadow text-center mb-30 white-bg">
					<div class="feature-icon">
						<span class="ti-write theme-color"></span>
					</div>
					<div class="feature-info">
						<h4 class="pb-10">Blended Learning</h4>
						<p>Blended learning is an approach to education that combines online educational materials and 
						 opportunities for interaction online with traditional place-based classroom methods.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="feature-text box-shadow text-center mb-30 white-bg">
					<div class="feature-icon">
						<span aria-hidden="true" class="ti-desktop theme-color"></span>
					</div>
					<div class="feature-info">
						<h4 class="pb-10">Online & Offline</h4>
						<p>Our online & Offline training program is a mix of self-paced, interactive and applied learning – better experience, better results
						We blend online learning and live virtual classroom training with mentorship and labs to get results.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="feature-text box-shadow text-center mb-30 white-bg">
					<div class="feature-icon">
						<span aria-hidden="true" class="ti-server theme-color"></span>
					</div>
					<div class="feature-info">
						<h4 class="pb-10">Projects</h4>
						<p>Our engaging learning platform, expert industry practitioners and support ninjas makes sure that you 
						complete the projects. our learning portal has a discussion forum where you can interact with other 
						learners.</p>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</section>
<!--=================================
 corporate service-->
 
 
 
 

<!--=================================
Corporate process-->
<section class="process-list white-bg page-section-pt">
	<div class="container">
		<div class="row ">
			<div class="col-sm-12"> 
				<div class="title mb-30">
					<h4 class="text-center">How it works</h4>
				</div>
				<div class="process left">
					<div class="process-step">
						<strong>01</strong>
					</div>
					<div class="process-content" style="z-index:999;">
						<div class="process-icon">
							<img class="lazy" alt="Industry Experts" src="img/corporate1.png" style="">
						</div>  
						<div class="process-info">
							<h5 class="mb-20 theme-color"> Your Learning Manager Gets in Touch with You</h5>
							<p>Share your learning objectives and get oriented with our web and mobile platform. 
							Talk to your personal learning manager to clarify your doubts.</p>
						</div>
					</div>
				   <div class="border-area left-bottom"></div>
				</div>
				<div class="process right">
					<div class="process-step">
						<strong>02</strong>
					</div>
					<div class="process-content text-right">
						<div class="process-icon">
							<img class="lazy" alt="Industry Experts" src="img/corporate2.png" style="">
						</div> 
						<div class="process-info">
							<h5 class="mb-20 theme-color"> Live Interactive Online Session with Your Instructor</h5>
							<p>Live screensharing, step-by-step live demonstrations and live Q&A led by industry experts. 
							Missed a class? Not an issue. We record the classes and upload them to your LMS.</p>
						</div>
					</div>
					<div class="border-area right-top"></div>
					<div class="border-area right-bottom"></div>
				</div>
				<div class="process left">
					<div class="process-step">
						<strong>03</strong>
					</div>
					<div class="process-content" style="z-index:999;">
						<div class="process-icon">
							<img class="lazy" alt="Industry Experts" src="img/corporate3.png" style="">
						</div>  
						<div class="process-info">
						<h5 class="mb-20 theme-color"> It’s Not Just about the Classes, We Make Sure You Practice</h5>
							<p>Quizzes & Assignments help you understand the concepts and solve problems. 
							Weekly Assignments & Quizzes are pre-loaded in your learning platform.</p>
						</div>
					</div>
					<div class="border-area left-bottom"></div>
					<div class="border-area left-top"></div>
				</div>
  
				<div class="process right">
					<div class="process-step">
						<strong>04</strong>
					</div>
					<div class="process-content text-right">
						<div class="process-icon">
							<img class="lazy" alt="Industry Experts" src="img/corporate4.png" style="">
						</div>  
						<div class="process-info">
							<h5 class="mb-20 theme-color"> Solve an Industry Live Use Case</h5>
							<p>Projects developed by industry experts gives you the experience of solving real-world 
							problems you will face in the corporate world</p>
						</div>
					</div>
					<div class="border-area right-top"></div>
				    <div class="border-area right-bottom"></div>
				</div>
      
				<div class="process left">
					<div class="process-step">
						<strong>05</strong>
					</div>
					<div class="process-content" style="z-index:999;">
						<div class="process-icon">
							<img class="lazy" alt="Industry Experts" src="img/corporate5.png" style="">
						</div> 
						<div class="process-info">
							<h5 class="mb-20 theme-color"> Get Certified and Fast Track Your Career Growth</h5>
							<p>Earn a valued certificate. Get help in creation of a professionally 
							written CV & Guidance for interview preparation & questions</p>
						</div>
					</div>
				    <div class="border-area left-bottom"></div>
				    <div class="border-area left-top"></div>
				</div>
			</div>
		</div>
    </div>
</section>
<!--=================================
 Corporate process-->

 
 
 
 


<!--=================================
Corporate faqs-->
<section class="service section-bg corporate">
	<div class="container">
        <div class="row mt-60 mb-40">
			<div class="col-lg-12 col-md-12 col-sm-12"> 
				<div class="title mb-30">
					<h4 class="text-center">Corporate Faq's</h4>
				</div>
				<div class="accordion border no-radius mb-30">
					<div class="acd-group">
						<a href="#" class="acd-heading">01. Why is corporate training important enterprises?</a>
						<div class="acd-des">Corporate training benefits organizations and employees alike by ensuring 
						swift acquisition of the capabilities needed to accomplish corporate goals and success, 
						as well as improving teamwork, employee satisfaction and retention, 
						as well as each employee's personal skillset, job value and career development. .</div>
					</div>
					<div class="acd-group">
						<a href="#" class="acd-heading">02. What skills are covered in our corporate training program?</a>
						<div class="acd-des">Our corporate training courses include Digital Marketing, Salesforce, 
						Cloud Computing, DevOps, Cyber Security, Software Development, Agile and Scrum,
						IT Service and Architecture, Project Management, Quality Management, UX and Design Thinking, 
						Business Productivity Tools, AI and Machine Learning, Big Data, and Data Science and Business Intelligence (BI).</div>
					</div>
					<div class="acd-group">
						<a href="#" class="acd-heading">03. Is there any minimum team size requirement for corporate training program?</a>
						<div class="acd-des">There is no minimum team size required to participate in Simplilearn's 
						corporate training program. No matter what your team size is, our Customer Success experts 
						will help you develop a learning path that’s ideal for your organization, whether you need to 
						train one single team member or an entire division.</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
Corporate faqs-->



<!--

<!--=================================
counter 
<section class="page-section-ptb" style="background-color:#dadada;">
	<div class="container">
		<div class="row text-center">
			<a class="btn corporate-contact" href="contact.php">Contact us</a>
		</div>
	</div>
</section>
<!--=================================
counter -->







<?php include('footer.php')  ?>

