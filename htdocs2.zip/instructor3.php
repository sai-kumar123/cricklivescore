
<?php include('header.php')  ?>


<!--=================================
page-title-->

<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">Instructor</h1>
				</div>
			</div>
		 </div>
	</div>
</div>

<!--=================================
page-title -->



<!--=================================
instructor -->
<section class="our-team white-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 sm-mb-30">
				<img class="img-responsive full-width" src="img/team3.png" alt="">
			</div>
			<div class="col-lg-8 col-md-8">
				<div class="team-details">
					<div class="clearfix">
						<div class="title pull-left mb-20">
							<h2 class="theme-color">MD Mahabub Ansari</h2>
							<span>Data Scientist(eBest Mobile)</span>
						</div>
						<div class="social-icons border color-hover pull-right mt-10">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i> </a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i> </a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i> </a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i> </a></li>
							</ul>
						</div>
					</div>
					<div class="clearfix">
						<p>Consectetur adipisicing eli. Vero quod conseqt quibusdam enim expedita sed quia nesciunt incidunt accusamus necessitatibus modi adipisci officia libero accusantium esse hic obcaecati. This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. </p>
					</div>    
					<div class="info mt-40 clearfix">
						<i class="fa fa-quote-left"></i> 
						<p>“Praesentium non tempore cum sapiente ut, lorem ipsum dolor sit amet, consectetur adipisicing elit. neque veniam amet soluta dicta illum, placeat vitae. Fugiat in temporibus harum voluptatem, iste quam. Saepe. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum, maxime nam corporis quod voluptas eius officiis obcaecati itaque.” </p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
instructor -->




<?php include('footer.php')  ?>

