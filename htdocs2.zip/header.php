<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Webster - Multi-Purpose HTML5 Template" />
<meta name="author" content="ineuron.ai" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>iNeuron Academy</title>

<!-- Favicon -->
<link rel="shortcut icon" href="img/favicon.png" />

<!-- font -->
<link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,500,500i,600,700,800,900|Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">
 
<!-- Plugins -->
<link rel="stylesheet" type="text/css" href="css/plugins-css.css" />

<!-- Typography -->
<link rel="stylesheet" type="text/css" href="css/typography.css" />

<!-- Shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes/shortcodes.css" />

<!-- Style -->
<link rel="stylesheet" type="text/css" href="css/style.css" />

<!-- Responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css" /> 
 
<!-- Style customizer -->
<link rel="stylesheet" type="text/css" href="css/style-customizer.css">
<link rel="stylesheet" type="text/css" href="css/skins/skin-blue.css" data-style="styles">
  
</head>

<body>

<div class="wrapper">


<!--=================================
 preloader -->
 
<div id="pre-loader">
	<img src="img/pre-loader.svg" alt="">
</div>

<!--=================================
 preloader -->




<!--=================================
user models-->
	<div class="modal fade" id="user-modal" tabindex="-1" role="dialog" >
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<div class="section-title mb-10">
						<h6>iNeuron</h6>
					</div>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span style="color:red;" aria-hidden="true">&times;</span></button>
				</div>
				<div class="row modal-body">
					<div class="col-12 white-bg">
						<div class="tab tab-border mb-20">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#login" data-toggle="tab"> Login</a></li>
								<li><a href="#signup" data-toggle="tab"> Sign up</a></li>
								<li><a href="#forgetpass" data-toggle="tab"> Forget Password</a></li>    
							</ul>
							<div class="tab-content">
								<div class="tab-pane fade in active" id="login">
									<div class="login-fancy clearfix">
										<form id="frm_login" method="post">
											<div class="section-field mb-20">
												<label class="mb-10" for="name">Email ID* </label>
												<input id="name" class="web form-control" type="email" placeholder="User name" name="email" required>
											</div>
											<div class="section-field mb-20">
												<label class="mb-10" for="Password">Password* </label>
												<input id="Password" class="Password form-control" type="password" placeholder="Password" name="Pass" required>
											</div>
											<button type="submit" name="lsubmit" class="button">
												<span>Log in</span>
												<i class="fa fa-check"></i>
											</button>
										</form>
									</div>
								</div>
								<div class="tab-pane fade" id="signup">
									<div class="login-fancy clearfix">
										<form name="usignup" class="usignup" id="usignup" method="post" action="php/signup.php">
											<div class="row">
												<div class="section-field mb-10 col-sm-6">
													<label class="mb-10" for="name">Name* </label>
													<input class="web form-control" type="text" placeholder="Name" name="usname" required>
												</div>
												<div class="section-field mb-10 col-sm-6">
													<label class="mb-10" for="name">Mobile number* </label>
													<input class="web form-control" type="number" placeholder="Mobile number" name="usphno" required>
												</div>
											</div>
											<div class="section-field mb-10">
												<label class="mb-10" for="name">Email* </label>
												<input type="email" placeholder="Email*" class="form-control" name="usemail" required>
											</div>
											<div class="section-field mb-10">
												<label class="mb-10" for="Password">Password* </label>
												<input class="Password form-control" type="password" placeholder="Password" name="uspass" required>
											</div>
											<button type="submit" name="ssubmit" class="button">
												<span>Signup</span>
												<i class="fa fa-check"></i>
											</button>											
										</form>
									</div>
								</div> 
								<div class="tab-pane fade" id="forgetpass">
									<div class="clearfix">
										<form class="upassrecovery" name="upassrecovery" id="upassrecovery">
											<div class="section-field mb-20">
											   <input class="form-control" type="text" placeholder="Email address" >
											</div>
											<button type="submit" name="ssubmit" class="button">
												<span>Recover your Password</span>
												<i class="fa fa-check"></i>
											</button>
										</form>
									</div>
								</div>
							</div> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!--=================================
 user models-->




<!--=================================
 header -->

<header id="header" class="header default fullWidth">
<!--=================================
 mega menu -->

	<div class="menu">  
		<!-- menu start -->
		<nav id="menu" class="mega-menu">
			<!-- menu list items container -->
			<section class="menu-list-items">
				<div class="container-fluid"> 
					<div class="row"> 
						<div class="col-lg-12 col-md-12"> 
							<!-- menu logo -->
							<ul class="menu-logo">
								<li>
									<a href="index.php"><img id="logo_img" src="img/logo.png" alt="logo"> </a>
								</li>
							</ul>
							<!-- menu links -->
							<div class="menu-bar">
								<ul class="menu-links">
									<li><a href="javascript:void(0)"> Courses <i class="fa fa-angle-down fa-indicator"></i></a>
										<!-- drop down multilevel  -->
										<ul class="drop-down-multilevel">
											<li><a href="javascript:void(0)">Data Science Masters</a></li>
											<li><a href="javascript:void(0)">Data Analytics</a></li>
											<li><a href="javascript:void(0)">Big Data</a></li>
											<li><a href="javascript:void(0)">Cloud Computing</a></li>
											<li><a href="javascript:void(0)">Fullstack Development</a></li>
											<li><a href="javascript:void(0)">UX / UI Design</a></li>
											<li><a href="javascript:void(0)">Devops</a></li>
										</ul>
									</li>
									<li><a href="javascript:void(0)"> Centers <i class="fa fa-angle-down fa-indicator"></i></a>
										<!-- drop down multilevel  -->
										<ul class="drop-down-multilevel">
											<li><a href="index.php">Banglore(India)</a></li>
											<li><a href="coming-soon.php">California(Usa)</a></li>
										</ul>
									</li>
									<li><a href="corporate.php">Corporate</a></li>
									<li><a href="coming-soon.php">Blog</a></li>
									<li><a href="coming-soon.php">Events</a></li>
									<li><a href="video.php">Videos</a></li>
									<li><a href="about.php">About</a></li>
									<li><a href="contact.php">Contact</a></li>
									
									<?php 
										if(isset($_SESSION["email"])){ ?>
											<li><a href="javascript:void(0)"> User <i class="fa fa-angle-down fa-indicator"></i></a>
												<ul class="drop-down-multilevel">
													<li><a href="uprofile.php">Profile</a></li>
													<li><a href="coming-soon.php">Cart</a></li>
													<li><a href="coming-soon.php">LMS</a></li>
													<li><a href="php/logout.php">Logout</a></li>
												</ul>
											</li>
										<?php }
										else{ ?>
											<li><a href="#" data-toggle="modal" data-target="#user-modal">Login</a></li>
										<?php }
									?>
								</ul>
								
								<!--
								<div class="search-cart">
									<div class="shpping-cart">
										<a class="cart-btn" href="#"> <i class="fa fa-shopping-cart icon"></i> <strong class="item">2</strong></a>
										<div class="cart">
											<div class="cart-title">
												<h6 class="uppercase mb-0">Shopping cart</h6>
											</div>
											<div class="cart-item">
												<div class="cart-image">
													<img class="img-responsive" src="images/shop/01.jpg" alt="">
												</div>
												<div class="cart-name clearfix">
													<a href="#">Product name <strong>x2</strong> </a>
													<div class="cart-price">
														<del>$24.99</del> <ins>$12.49</ins>
													</div>
												</div>
												<div class="cart-close">
													<a href="#"> <i class="fa fa-times-circle"></i> </a>
												</div>
											</div>
											<div class="cart-item">
												<div class="cart-image">
													<img class="img-responsive" src="images/shop/01.jpg" alt="">
												</div>
												<div class="cart-name clearfix">
													<a href="#">Product name <strong>x2</strong></a>
													<div class="cart-price">
														<del>$24.99</del> <ins>$12.49</ins>
													</div>
												</div>
												<div class="cart-close">
													<a href="#"> <i class="fa fa-times-circle"></i> </a>
												</div>
											</div>
											<div class="cart-total">
												<h6 class="mb-15"> Total: $104.00</h6>
												<a class="button" href="#">View Cart</a>
												<a class="button black" href="#">Checkout</a>
											</div>
										</div>
									</div>
								</div>
								-->
								
							</div>
						</div>
					</div>
				</div>
			</section>
		</nav>
		<!-- menu end -->
	</div>
</header>

<!--=================================
 header -->

