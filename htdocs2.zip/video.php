
<?php include('header.php')  ?>


<!--=================================
page-title-->
<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">Video</h1>
				</div>
			</div>
		 </div>
	</div>
</div>
<!--=================================
page-title -->



<!--=================================
Video -->
<section class="page-section-ptb">
	<div class="container">
     
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 sm-mb-30">
				<div class="js-video [youtube, widescreen]">
					<iframe src="https://www.youtube.com/embed/l4T1jRN3DL8?rel=0" allowfullscreen></iframe>
				</div><br/>&nbsp;
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 sm-mb-30">
				<div class="js-video [youtube, widescreen]">
					<iframe src="https://www.youtube.com/embed/4UhSceUbhxI?rel=0" allowfullscreen></iframe>
				</div><br/>&nbsp;
			</div>
			
			<div class="col-lg-6 col-md-6 col-sm-6 sm-mb-30">
				<div class="js-video [youtube, widescreen]">
					<iframe src="https://www.youtube.com/embed/4UhSceUbhxI?rel=0" allowfullscreen></iframe>
				</div><br/>&nbsp;
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 sm-mb-30">
				<div class="js-video [youtube, widescreen]">
					<iframe src="https://www.youtube.com/embed/qLOBYJpNVqs?rel=0" allowfullscreen></iframe>
				</div><br/>&nbsp;
			</div>
			
			<div class="col-lg-6 col-md-6 col-sm-6">
				<div class="js-video [vimeo, widescreen]">
					<iframe src="https://www.youtube.com/embed/FaHHThgfbxo?rel=0"></iframe>
				</div>
			</div>
			
			<div class="col-lg-6 col-md-6 col-sm-6">
				<div class="js-video [vimeo, widescreen]">
					<iframe src="https://www.youtube.com/embed/nmj1LVBB4uQ?rel=0"></iframe>
				</div>
			</div>
			
		</div>

	</div>
</section>
<!--=================================
Video -->



<?php include('footer.php')  ?>

