<?php
  
session_start(); 
require_once 'uconfig.php';

$results = '';

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$age = $_POST['age'];

$email = $_SESSION["email"];

$sql = "SELECT * FROM academy_user where email = '$email'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		if(empty($name)){ $name = $row["name"]; }
		if(empty($mobile)){ $mobile = $row["mobile"]; }
		if(empty($age)){ $age = $row["age"]; }
		if(empty($_POST['gender'])){ $gender = $row["gender"]; }else{$gender = $_POST['gender']; }
	}
}

$sql = "UPDATE academy_user SET name = '$name', mobile = '$mobile', age = '$age', gender = '$gender' WHERE email = '$email'";

if ($conn->query($sql) === TRUE) {
    $results = "usuccess";
} else {
    $results = "Update failed";
}

echo $results;

$conn->close();
?>