<?php
  
session_start(); 
require_once 'uconfig.php';

$results = '';

$oldpass = $_POST['curpass'];
$newpass = $_POST['newpass'];

$email = $_SESSION["email"];

$sql = "SELECT * FROM academy_user where email = '$email'";
$result = $conn->query($sql);
if ($result->num_rows > 0){
	while($row = $result->fetch_assoc()){ $pass = $row["pass"]; }
	if($pass == $oldpass){
		$sql = "UPDATE academy_user SET pass = '$newpass' WHERE email = '$email'";
		if ($conn->query($sql) === TRUE){ $results = "Password hasbeen updated successfully"; }
		else { $results = "Password update failed."; }
	}
	else{ $results = "Your current password is incorrect."; }
}

echo $results;

$conn->close();
?>