<?php
session_start(); 
require_once 'uconfig.php';

$email = $_SESSION["email"];
$results = "";
$target_dir = "../utemp/";
$target_file1 = basename($_FILES["upic"]["name"]);
$target_file  = 'upic-' . time() . '.' . strtolower(pathinfo($_FILES['upic']['name'], PATHINFO_EXTENSION));

$imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
if($_FILES["upic"]["size"] > 500000){ $results = "Sorry, File size is too large."; }
elseif($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ){
    $results = "Sorry, not an valid image file type.";
} 
else{
    if(move_uploaded_file($_FILES["upic"]["tmp_name"], $target_dir . $target_file)){
		$dppath = "utemp/" . $target_file;
		$sql = "UPDATE academy_user SET dppath = '$dppath' WHERE email = '$email'";
		if ($conn->query($sql) === TRUE){ $results = "success"; } else{ $results = "Update failed"; }
    } 
	else{ $results = "Sorry, there was an error uploading your file."; }
}

if($results == "success"){
	header('Location: ../uprofile.php');
}
else{
	$_SESSION["error"] = $results;
	header('Location: ../error404.php');
}

$conn->close();
?>