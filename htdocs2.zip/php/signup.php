<?php

session_start();
	
	require_once 'uconfig.php';
		
	$name = $_POST['usname'];       
	$phone = $_POST['usphno'];     
	$email  = $_POST['usemail'];    
	$pass = $_POST['uspass']; 

	// sql to create table
	$sql = "CREATE TABLE IF NOT EXISTS academy_user(
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	name VARCHAR(50),
	mobile VARCHAR(50),
	email VARCHAR(50) NOT NULL UNIQUE,
	pass VARCHAR(50),
	age VARCHAR(50),
	gender VARCHAR(50),
	dppath VARCHAR(50),
	lmspath VARCHAR(120),
	orders VARCHAR(120),
	reg_date TIMESTAMP
	)";
	
	if ($conn->query($sql) === TRUE){
		$sql = "SELECT email FROM academy_user where email = '$email'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) { $_SESSION["error"] = "You have already registered.";header('Location: ../error404.php');}
		else{		
			$sql = "INSERT INTO academy_user(name,mobile,email,pass,dppath) VALUES('$name','$phone','$email','$pass','utemp/avatar.png')";
			if ($conn->query($sql) === TRUE){
				$_SESSION["email"] = $email;
				if(isset($_SESSION["email"])){ header('Location: ../uprofile.php'); }
			} else{ header('Location: ../error404.php'); }
		}		
	} 
	else{
		header('Location: ../error404.php');
	}
		
$conn->close();	
?>