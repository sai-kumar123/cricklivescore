<?php
session_start(); 
require_once 'uconfig.php';

$results = '';

$email = $_POST['email'];
$pass = $_POST['Pass'];
	
$sql = "SELECT email FROM academy_user where email = '$email' AND pass = '$pass'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { 
	$_SESSION["email"] = $email;
	if(isset($_SESSION["email"])){ $results = "lsuccess"; }
}
else {$results = "User name or Password wrong.";}

echo $results;

$conn->close();
?>