<?php
  
require_once 'uconfig.php';

$results = '';

if(isset($_POST['usubemail']) && $_POST['usubemail']){

	$email = $_POST['usubemail'];  
	
	// sql to create table
	$sql = "CREATE TABLE IF NOT EXISTS news_letter (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	email VARCHAR(50),
	reg_date TIMESTAMP
	)";

	if ($conn->query($sql) === TRUE){
		
		$sql = "SELECT email FROM news_letter where email = '$email'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) { $results = "You have subscribed already.";}
		else {		
			$sql = "INSERT INTO news_letter(email) VALUES('$email')";
			if ($conn->query($sql) === TRUE){$results = "Successfully subscribed to news letter.";} 
			else{ $results = "Data insertion operation failed, try after some time."; }
		}
	} 
	else{ $results = "Table creation failed, try after some time."; }	
}
else{ $results = "No data to server."; }

echo $results;

$conn->close();
?>