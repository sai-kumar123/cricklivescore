$(document).ready(function(){
	
	//subscribe form
	$('#frm_subscribe').submit(function(e){
		e.preventDefault();
		$.ajax({
			type: "POST",
			url: 'php/news_letter.php',
			data: $(this).serialize(),
			success: function(response){
				alert(response);
			}
		})
	})
	
	//login form
	$('#frm_login').submit(function(e){
		e.preventDefault();
		$.ajax({
			type: "POST",
			url: 'php/login.php',
			data: $(this).serialize(),
			success: function(res){
				if(res == "lsuccess"){
					window.location.replace("../uprofile.php");
				}else{alert(res);}
			}
		})
	})
	
	//update form
	$('#frm_update').submit(function(e){
		e.preventDefault();
		$.ajax({
			type: "POST",
			url: 'php/update.php',
			data: $(this).serialize(),
			success: function(res){
				if(res == "usuccess"){
					window.location.replace("../uprofile.php");
				}else{alert(res);}
			}
		})
	})
	
	//update password
	$('#frm_passupdate').submit(function(e){
		e.preventDefault();
		$.ajax({
			type: "POST",
			url: 'php/passupdate.php',
			data: $(this).serialize(),
			success: function(res){
				alert(res);
			}
		})
	})
			
})


