<?php 
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Webster - Multi-Purpose HTML5 Template" />
<meta name="author" content="ineuron.ai" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>iNeuron Academy</title>

<!-- Favicon -->
<link rel="shortcut icon" href="img/favicon.png" />

<!-- font -->
<link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,500,500i,600,700,800,900|Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">
 
<!-- Plugins -->
<link rel="stylesheet" type="text/css" href="css/plugins-css.css" />

<!-- Typography -->
<link rel="stylesheet" type="text/css" href="css/typography.css" />

<!-- Shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes/shortcodes.css" />

<!-- Style -->
<link rel="stylesheet" type="text/css" href="css/style.css" />

<!-- Responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css" /> 
 

  
</head>

<body>

<div class="wrapper">


<!--=================================
 preloader -->
 
<div id="pre-loader">
	<img src="img/pre-loader.svg" alt="">
</div>

<!--=================================
 preloader -->

<!--=================================
error -->
<div class="height-100vh parallax" style="background-image: url(img/error404.jpg);">
	<div class="error-06 error-middle page-section-ptb">
		<div class="container">
			<div class="col-md-offset-3 col-md-6">
				<h1 class="text-white">404</h1>
				<h2 class="text-white">
					<?php if(isset($_SESSION["error"])){ echo $_SESSION["error"];unset($_SESSION["error"]); } else{ echo 'Page Not Found'; } ?>
				</h2>
				<p class="text-white"> Don't worry, sometimes it happens even for the best of us :)</p>
				<a class="button white border mt-30" href="index.php">Back to home</a>
			</div>
		</div>
	</div>
</div>
<!--=================================
error -->


</div>

<!--=================================
 jquery -->

<!-- jquery -->
<script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>

<!-- plugins-jquery -->
<script type="text/javascript" src="js/plugins-jquery.js"></script>

<!-- plugin_path -->
<script type="text/javascript">var plugin_path = 'js/';</script>
 
<!-- custom -->
<script type="text/javascript" src="js/custom.js"></script>

<!--End of Tawk.to Script-->
 
</body>
</html>

