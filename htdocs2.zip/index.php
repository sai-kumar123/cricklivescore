<?php include('header.php')  ?>
 
 
 

<!--=================================
 banner -->
<section id="home-slider" class="shop-04-banner">
    <div id="main-slider" class="carousel carousel-fade slide" data-ride="carousel">
		<!-- Indicators -->
        <ol class="carousel-indicators">
			<li data-target="#main-slider" data-slide-to="0" class="active"></li>
			<li data-target="#main-slider" data-slide-to="1"></li>
        </ol>
        <!-- Carousel inner -->
        <div class="carousel-inner">
			<!--/ Carousel item end -->
			<div class="item active">
				<img class="img-responsive" src="img/banner1.jpg" alt="slider">  
				<div class="slider-content">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center">
								<div class="slider">
									<h1 class="text-white animated5">Succeed in today's data-driven world</h1>
									<span class="text-gray mb-30 animated5">Master in-demand skills and achieve your career goals</span>
									<a class="button black ml-10 animated5" href="#">Know more </a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<img class="img-responsive" src="img/banner2.jpg" alt="slider">
				<div class="slider-content">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center">
								<div class="slider">
									<h1 class="text-white animated5">Become an Analytics expert</h1>
									<span class="text-gray mb-30 animated5">Learn from India's No.1 analytics program</span>
									<a class="button black ml-10 animated5" href="#">Know more </a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ Carousel item end -->
        </div>
		<!-- Controls -->
        <a class="left carousel-control" href="#main-slider" data-slide="prev">
			<span><i class="fa fa-angle-left"></i></span>
        </a>
        <a class="right carousel-control" href="#main-slider" data-slide="next">
			<span><i class="fa fa-angle-right"></i></span>
        </a>
    </div>
  </section>
<!--=================================
 banner -->





<!--=================================
start info -->
<section class="white-bg">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="section-title text-center mt-50">
					<h2 class="title-effect">Why Learn At iNeuron</h2>
				</div>
			</div> 
		</div>
		<div class="why-learning mb-50">
			<div class="row why-blocks">
				<div class="col-md-3 text-center">
					<div class="row align-items-center">
						<div class="col-md-12 col-3">
							<img class="lazy" alt="Industry Experts" src="img/info1.png" style="">
						</div>
					<div class="col-md-12 col-9">
						<h3 class="white">90+ </h3>
						<p class="white">Industry Experts as Mentors</p>
					</div>
					</div>
				</div>
				
				<div class="col-md-3 text-center">
					<div class="row align-items-center">
						<div class="col-md-12 col-3">
							<img class="lazy" alt="Great Learning Successful Learners" src="img/info2.png" style="">
						</div>
						<div class="col-md-12 col-9">
							<h3 class="white">5000+  </h3>
							<p class="white">Successful Learners</p>
						</div>
					</div>
				</div>
			  
				<div class="col-md-3 text-center">
					<div class="row align-items-center">
						<div class="col-md-12 col-3">
							<img class="lazy" alt="Great Learning learning hours delivered" src="img/info3.png" style="">
						</div>
						<div class="col-md-12 col-9">
							<h3 class="white">3 Million+   </h3>
							<p class="white">Learning Hours Delivered</p>
						</div>
					</div>
				</div>
			  
				<div class="col-md-3 text-center">
					<div class="row">
						<div class="col-md-12 col-3">
							<img class="lazy" alt="Great Learning Career Transitions" src="img/info4.png" style="">
						</div>
						<div class="col-md-12 col-9">
							<h3 class="white">60+</h3>
							<p class="white">Hiring Companies</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
start info -->



 
 


<!--=================================
 Popular Courses-->
<section class="section-bg page-section-ptb courses">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="section-title text-center">
					<h2 class="title-effect">Our popular courses</h2>
				</div>
			</div> 
		</div>
		
		<div class="owl-carousel row row-eq-height" style="margin:auto;" data-nav-arrow="true" data-items="3" data-md-items="3" data-sm-items="1" data-xs-items="1" data-xx-items="1">
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cds.jpg');">
							<div class="cg-2 course-gradient">
							  <div><h4>Data Science Masters</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cda.jpg');">
							<div class="cg-3 course-gradient">
							  <div><h4>Data Analytics</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cbd.jpg');">
							<div class="cg-1 course-gradient">
							  <div><h4>Big Data</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/ccld.jpg');">
							<div class="cg-2 course-gradient">
							  <div><h4>Cloud Computing</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cfs.jpg');">
							<div class="cg-3 course-gradient">
							  <div><h4>Full Stack Development</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cux.jpg');">
							<div class="cg-1 course-gradient">
							  <div><h4>UX / UI Design</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
			
			<div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12 course-list-card" style="margin:20px 10px;">
				<a href="">
					<div class="course-list-img">
						<div class="couse-list-thumb course-hero-home lazy" style="background-image: url('img/cdvop.jpg');">
							<div class="cg-2 course-gradient">
							  <div><h4>Devops</h4></div>
							  <div><p class="white card-title-small"><small>Classroom or Online<span>|</span>6 Months</small></p></div>
							</div>
						</div>
					</div>
					<div class="col-md-12 col-12 course-list-content-wrap">
						<div class="course-list-content">
						<h6 class="uppercase">INDIA'S MOST EXHAUSTIVE Data Science Program</h6>
						<ul class="list-unstyled">
							<li>Dual Certificate from The University of Texas at Austin and Great Lakes</li>
							<li>Dedicated 6 months focus on Deep Learning</li>
							<li>12 real-life projects + 1 Capstone</li>
							<li>Machine Learning, Deep learning, Computer vision, NLP</li>
							<li>GPU accelerated AI lab</li>
							<li>Python, Tensor Flow, Keras, NLTK</li>
						</ul><br/>
						<p><span class="ti-timer theme-color" aria-hidden="true"></span>&nbsp;Applications Close <strong style="font-weight:600;">Tomorrow</strong></p>
							<div class="text-right course-list-content-icon">
								<img src="img/course_card_arrow.svg" alt="Great Learning courses">
							</div>
						</div>
					</div>
				</a>
			</div>
		
		</div>
		
	</div>
</section>
<!--=================================
 popular courses-->





 
<!--=================================
 About-->
<section class="page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<div class="section-title">
					<h6>Who we are and what we do</h6>
					<h2 class="title-effect">Get to know us better.</h2>
					<p>We truly care about our users and our product. We are dedicated to providing you with the best experience possible. </p>
				</div> 
				<p>Let's make something great together consectetur adipisicing elit. <span class="theme-color" data-toggle="tooltip" data-placement="top" title="" data-original-title="HTML5 template">Webster</span>  conseqt quibusdam, enim expedita sed quia nesciunt. Vero quod conseqt quibusdam, enim expedita sed quia nesciunt incidunt accusamus necessitatibus</p>
				<div class="row mt-30 sm-mb-40">
					<div class="col-md-6">
						<ul class="list list-unstyled list-hand">
							<li> Award-winning design</li>
							<li> Super Fast Customer support </li>
						</ul>
					</div>
					<div class="col-md-6">
						<ul class="list list-unstyled list-hand">
							<li> Easy to Customize pages</li>
							<li> Powerful Performance </li>
						</ul>
					</div>
				</div>
			</div>  
		  <div class="col-lg-6 col-md-6 xs-mt-30 xs-mb-30">
			<div class="owl-carousel" data-nav-arrow="true" data-items="1" data-md-items="1" data-sm-items="1" data-xs-items="1" data-xx-items="1">
			  <div class="item">
				 <img class="img-responsive full-width" src="img/about1.jpg" alt="">
			   </div>
			  <div class="item">
				<img class="img-responsive full-width" src="img/about2.jpg" alt="">
			  </div>
			  <div class="item">
				<img class="img-responsive full-width" src="img/about3.jpg" alt="">
			  </div>
			 </div>
		  </div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 xs-mb-30">
				<div class="feature-text m left-icon mt-60">
					<div class="feature-icon">
						<span class="ti-desktop theme-color" aria-hidden="true"></span>
					</div>
					<div class="feature-info">
						<h5>Our company</h5>
						<p>Enim expedita sed quia nesciunt dolor sit consectetur conseqt quibusdam</p>
					</div>
				</div> 
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 xs-mb-30">
				<div class="feature-text left-icon mt-60">
					<div class="feature-icon">
						<span class="ti-server theme-color" aria-hidden="true"></span>
					</div>
					<div class="feature-info">
						<h5>Our Mission</h5>
						<p>Conseqt quibusdam, enim expedita sed quia nesciunt dolor sit consectetur</p>
					</div>
				</div> 
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="feature-text left-icon mt-60">
					<div class="feature-icon">
						<span class="ti-heart theme-color" aria-hidden="true"></span>
					</div>
					<div class="feature-info">
						<h5 class="text-back">We Love</h5>
						<p>Expedita sed quia nesciunt dolor sit consectetur conseqt quibusdam enim</p>
					</div>
				</div> 
			</div>
		</div>
	</div>
</section>
<!--=================================
 About-->
 
 
 
 
 
<!--=================================
most Awesome- -->
<section class="page-section-ptb what-we-do" data-jarallax='{"speed": 0.6}' style="background: url(img/what-we-do.jpg);">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<div class="section-title">
					<h6 class="text-white">What we do?</h6>
					<h2 class="text-white title-effect">We do things differently</h2>
					<p class="text-white">We have a commitment to the training and a daily focus on helping our students solve problems. </p>
				</div> 
				<p class="text-white">Using the following principles, we set out to provide and optimise our training towards every individual student. 
					We measure our success by the long term satisfaction of our students, and our own ability to understand our students’s needs.</p>
				<div class="row mt-30">
					<div class="col-sm-6 col-xs-6 col-xx-12">
						<ul class="list list-unstyled list-hand">
							<li class="text-white"> Transparency</li>
							<li class="text-white"> Quality</li>
						</ul>
					</div>
					<div class="col-sm-6 col-xs-6 col-xx-12">
						<ul class="list list-unstyled list-hand">
							<li class="text-white"> Efficiency</li>
							<li class="text-white"> Flexibility</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
most Awesome- -->




<!--=================================
our-team  -->
 <section class="our-team white-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="section-title text-center">
					<h6>Meet our Superheros</h6>
					<h2 class="title-effect">Our creative team </h2>
				</div>
			</div> 
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 sm-mb-30">
				<div class="team team-round">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team1.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info"> 
							<h5><a href="instructor1.php"> Sudhanshu Kumar</a></h5>
							<span>CEO(iNeuron)</span>
						</div>
						<div class="social-icons border rounded color-hover clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 sm-mb-30">
				<div class="team team-round">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team2.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info"> 
							<h5><a href="instructor2.php"> Krish Naik</a></h5>
							<span>DATA SCIENTIST(Panasonic)</span>
						</div>
						<div class="social-icons border rounded color-hover clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 xs-mb-30">
				<div class="team team-round">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team3.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info"> 
							<h5><a href="instructor3.php"> MD Mahabub Ansari</a></h5>
							<span>Data Scientist(eBest Mobile)</span>
						</div>
						<div class="social-icons border rounded color-hover clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>  
			<div class="col-lg-3 col-md-3 col-sm-6 xs-mb-30">
				<div class="team team-round">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team4.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info"> 
							<h5><a href="instructor4.php"> Khushboo Gupta</a></h5>
							<span>Data Scientist(E&Y, IIT Bombay)</span>
						</div>
						<div class="social-icons border rounded color-hover clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
our-team -->




 
<!--=================================
counter -->
<section class="page-section-ptb theme-bg">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xx-12 xs-mb-30">
				<div class="counter left-icon text-white">
					<span class="icon ti-user theme-color" aria-hidden="true"></span>
					<span class="timer" data-to="4905" data-speed="3000">4000</span>
					<label>STUDENTS TRAINED</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xx-12 xs-mb-30">
				<div class="counter left-icon text-white">
					<span class="icon ti-server theme-color" aria-hidden="true"></span>
					<span class="timer" data-to="3750" data-speed="3000">300</span>
					<label>PROJECTS</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xx-12 xs-mb-30">
				<div class="counter left-icon text-white">
					<span class="icon ti-check-box theme-color" aria-hidden="true"></span>
					<span class="timer" data-to="4782" data-speed="3000">3300</span>
					<label>STUDENTS PLACED</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xx-12">
				<div class="counter left-icon text-white">
					<span class="icon ti-face-smile theme-color" aria-hidden="true"></span>
					<span class="timer" data-to="3237" data-speed="3000">5525</span>
					<label>HAPPY CLIENTS</label>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
counter -->




<!--=================================
Alumni Companies --->
<section class="container spacer-2x">
	<div class="alumni-partners">
		<div class="row mt-60">
			<div class="col-12">
				<div class="section-title text-center">
					<h2 class="heading title-effect mb-10">Our Alumni Work for Amazing Companies</h2>
					<p class="text-center">Our programs are designed to give you the skills you need to be successful in your career.</p>
				</div>
			</div>
		</div>
		<div class="spacer-2x mb-60">
			<picture>
				<source media="(min-width: 650px)" srcset="https://d1vwxdpzbgdqj.cloudfront.net/assets/alumni/Alumni-medium-ef333c998f1ca48aba6b080e7b9d57b24bdbd26c50de91b9d63610afd1e7e96f.jpg">
				<img class="img-responsive lazy" src="https://d1vwxdpzbgdqj.cloudfront.net/assets/alumni/alumni-small-d1612e1d8144b752b5f218293510d3252574c4b3d61a8f5cf2980158f2fbdbc6.jpg" style="">
			</picture>
		</div>
	</div>
</section>
<!--=================================
Alumni Companies --->




<!--=================================
video carousel -->
<section class="section-bg alumni">
	<div class="container">
		<div class="row mt-60">
			<div class="col-12">
				<div class="section-title text-center">
					<h2 class="title-effect">Alumni words</h2>
				</div>
			</div>
		</div>
		<div class="row mb-60">
			<div class="col-lg-12 col-md-12">
				<div class="owl-carousel" data-nav-dots="true" data-items="3" data-md-items="3" data-sm-items="3" data-xs-items="2" data-xx-items="1" data-space="20">
					<div class="item">
						<div class="js-video [vimeo, widescreen]">
							<iframe src="https://www.youtube.com/embed/nmj1LVBB4uQ?rel=0"></iframe>
						</div>
					</div>
					<div class="item">
						<div class="js-video [vimeo, widescreen]">
							<iframe src="https://www.youtube.com/embed/nmj1LVBB4uQ?rel=0"></iframe>
						</div>
					</div>
					<div class="item">
						<div class="js-video [vimeo, widescreen]">
							<iframe src="https://www.youtube.com/embed/nmj1LVBB4uQ?rel=0"></iframe>
						</div>
					</div>
					<div class="item">
						<div class="js-video [vimeo, widescreen]">
							<iframe src="https://www.youtube.com/embed/nmj1LVBB4uQ?rel=0"></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
video carousel --> 





<section class="service white-bg page-section-ptb media">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title text-center">
					<h2 class="title-effect">Media Mentions</h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="bg-gray feature-text box-shadow text-center mb-10">
					<div class="feature-icon">
						<img alt="ET Tech" class=" mb-10" src="img/media1.png" style="">
					</div>
					<div class="feature-info">
						<p class="card-subtitle mb-15 mt-10 text-muted text-left">24 June, 2019</p>
						<p class="card-title mb-10 mt-10 text-left">How upskilling can make the return to work easier</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="bg-gray feature-text box-shadow text-center mb-10">
					<div class="feature-icon">
						<img alt="ET Tech" class=" mb-10" src="img/media2.jpg" style="">
					</div>
					<div class="feature-info">
						<p class="card-subtitle mb-15 mt-10 text-muted text-left">24 June, 2019</p>
						<p class="card-title mb-10 mt-10 text-left">How upskilling can make the return to work easier</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="bg-gray feature-text box-shadow text-center mb-10">
					<div class="feature-icon">
						<img alt="ET Tech" class=" mb-10" src="img/media3.jpg" style="">
					</div>
					<div class="feature-info">
						<p class="card-subtitle mb-15 mt-10 text-muted text-left">24 June, 2019</p>
						<p class="card-title mb-10 mt-10 text-left">How upskilling can make the return to work easier</p>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</section>
<!--=================================
media mentions --> 




<!--=================================
Newsletter --->
<section class="action-box section-bg full-width">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<h3 class="text-center mt-60 mb-40">Subscribe to our news letter</h3>
				<div class="row newsletter mt-30 mb-80 text-center">
					<form id="frm_subscribe" method="post" > 
						<div class="col-sm-12 col-md-9">
							<input class="form-control placeholder" type="email" placeholder="Email address" name="usubemail" value="" required>
						</div>
						<div class="col-sm-12 col-md-3">
							<div class="clear">
								<input type="submit" class="button border form-button" name="subsubmit" id="subsubmit" value="Subscribe" />
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
Newsletter --->




<?php include('footer.php')  ?>


  
<!--=================================
 jquery -->


 

<!-- REVOLUTION JS FILES -->
<script type="text/javascript" src="revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>
<!-- revolution custom --> 
<script type="text/javascript" src="revolution/js/revolution-custom.js"></script> 



