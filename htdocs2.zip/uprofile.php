<?php  
	include('header.php');
	require_once 'php/uconfig.php';
?>

<!--=================================
page-title-->

<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">User Profile</h1>
				</div>
			</div>
		 </div>
	</div>
</div>

<!--=================================
page-title -->






<!--=================================
about -->
<section class="profile section-bg">
	<div class="container">
		<div class="row mt-50 mb-50">    
			<div class="col-lg-12 col-md-12">
				<div class="tab tab-border">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#profile" data-toggle="tab">Profile</a></li>
						<li><a href="#settings" data-toggle="tab"> Settings</a></li> 
						<li><a href="#password" data-toggle="tab"> Password Update</a></li>
						<li><a href="#profilepic" data-toggle="tab"> Profile Pic update</a></li>
						<li><a href="#cart" data-toggle="tab"> Cart</a></li>
					</ul>
					<div class="tab-content white-bg">
						<div class="tab-pane fade in active" id="profile">
							<?php
								if(isset($_SESSION["email"])){
									$email = $_SESSION["email"];
									$sql = "SELECT * FROM academy_user where email = '$email'";
									$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while($row = $result->fetch_assoc()) {
										?>
											<div class="row dp-page">
												<div class="col-md-6 img">
													<img height="300" width="250" src="<?php echo $row["dppath"]; ?>"  alt="" class="img-rounded">
												</div>
												<div class="col-md-6 details">
													<blockquote>
														<h3><?php echo $row["name"]; ?></h3>
													</blockquote>
													<p>
														Age : <?php echo $row["age"]; ?><br>
														Mobile : <?php echo $row["mobile"]; ?><br>
														Gender : <?php echo $row["gender"]; ?>
													</p>
												</div>
											</div><?php
										}
									}
								}else{ header('Location: index.php');exit(0); } ?>		
						</div>
						<div class="tab-pane fade" id="settings">							
							<div class="login-fancy clearfix">
								<form id="frm_update" method="post">
									<div class="section-field mb-20">
										<label class="mb-10" for="name">Name </label>
										<input id="name" class="web form-control" type="text" name="name">
									</div>
									<div class="section-field mb-20">
										<label class="mb-10" for="name">Mobile </label>
										<input id="name" class="web form-control" type="number" name="mobile">
									</div>
									<div class="section-field mb-20">
										<label class="mb-10" for="name">Age </label>
										<input id="name" class="web form-control" type="number" name="age">
									</div>									
									<div class="form-group">
										<label for="sname"><b>Gender:</b></label>
										<div class="form-check-inline">
											<label class="form-check-label">
											  <input type="radio" class="form-check-input" value="female" id="gender" name="gender">Female
											</label>
										</div>
										<div class="form-check-inline">
											<label class="form-check-label">
												<input type="radio" class="form-check-input" value="male" id="gender" name="gender">Male
											</label>
										</div>
									</div>
									<button type="submit" name="pubmit" class="button">
										<span>Update</span>
										<i class="fa fa-check"></i>
									</button>
								</form>
							</div>						
						</div>
						<div class="tab-pane fade" id="password">
							<form id="frm_passupdate" method="post">
								<div class="section-field mb-20">
									<label class="mb-10" for="name">Current Password </label>
									<input id="name" class="web form-control" type="password" name="curpass" required>
								</div>
								<div class="section-field mb-20">
									<label class="mb-10" for="name">New Password </label>
									<input id="name" class="web form-control" type="password" name="newpass" required>
								</div>
								<button type="submit" name="pubmit" class="button">
									<span>Update</span>
									<i class="fa fa-check"></i>
								</button>
							</form>
						</div>
						<div class="tab-pane fade" id="profilepic">
							<form name="frmupic" action="php/uprofilepic.php" method="post" enctype="multipart/form-data">
								<div class="section-field mb-20">
									<label class="mb-10" for="name">Profile pic </label>
									<input class="web form-control" type="file" id="upic" name="upic" required>
								</div>
								<button type="submit" name="upsubmit" class="button">
									<span>Update</span>
									<i class="fa fa-check"></i>
								</button>
							</form>
						</div>
						<div class="tab-pane fade" id="cart">
							<form id="tab2">
								<label>New Password</label>
								<input type="password" class="input-xlarge">
								<div>
									<button class="btn btn-primary">Update</button>
								</div>
							</form>
						</div>
						
					</div> 
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
about -->





<?php include('footer.php')  ?>

