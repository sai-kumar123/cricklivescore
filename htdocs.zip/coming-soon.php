<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="Webster - Multi-Purpose HTML5 Template" />
<meta name="author" content="ineuron.ai" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>iNeuron Academy</title>

<!-- Favicon -->
<link rel="shortcut icon" href="img/favicon.png" />

<!-- font -->
<link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,500,500i,600,700,800,900|Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">
 
<!-- Plugins -->
<link rel="stylesheet" type="text/css" href="css/plugins-css.css" />

<!-- Typography -->
<link rel="stylesheet" type="text/css" href="css/typography.css" />

<!-- Shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes/shortcodes.css" />

<!-- Style -->
<link rel="stylesheet" type="text/css" href="css/style.css" />

<!-- Responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css" /> 
 
<!-- Style customizer -->
<link rel="stylesheet" type="text/css" href="css/style-customizer.css">
<link rel="stylesheet" type="text/css" href="css/skins/skin-blue.css" data-style="styles">
  

</head>

<body>

<div class="wrapper">

<!-- bubble -->
<link rel="stylesheet" type="text/css" href="css/bubble.css" />

<!-- Responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css" /> 

<div id="bubble" class="coming-soon-effects" style="background: url('img/coming-soon.jpg');">
    <canvas id="canvas"></canvas>
</div>


<br/><br/><br/>
<!--=================================
coming-soon-->
<section class="page-section-ptb coming-soon">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-2 col-md-8">
				<div class="mt-20 section-title text-center">
					<h1 class="text-white">We are <span class="theme-color"> coming very soon! </span></h1>
					<p class="text-white">We are currently working on a website and won't take long.<br/> Don't forget to check out our Social updates.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 text-center">
				<div class="coming-soon-form text-center contact-form transparent-form clearfix mt-30">
					<a href="index.php"><img style="padding:10px;border-radius:20px;" class="logo-small section-bg" id="logo_img" src="img/logo.png" alt="logo"> </a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
coming-soon-->
 
 
 
 </div>
 
 <!--=================================
 jquery -->

<!-- jquery -->
<script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>

<!-- plugins-jquery -->
<script type="text/javascript" src="js/plugins-jquery.js"></script>

<!-- plugin_path -->
<script type="text/javascript">var plugin_path = 'js/';</script>

<!-- custom -->
<script type="text/javascript" src="js/custom.js"></script>


 
</body>
</html>
 
<!-- bubble -->
<script type="text/javascript" src="js/bubble.js"></script>

