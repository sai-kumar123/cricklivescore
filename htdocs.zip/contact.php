
<?php include('header.php')  ?>






<!--=================================
page-title-->
<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">Contact</h1>
				</div>
			</div>
		 </div>
	</div>
</div>
<!--=================================
page-title -->






<!--=================================
contact-->
<section class="contact section-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-md-offset-2">
				<div class="section-title text-center">
					<h6>let's work together</h6>
					<h2>Let’s Get In Touch!</h2>
					<p>It would be great to hear from you! If you got any questions</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="touch-in">
				<div class="col-lg-4 col-md-4 col-sm-4">
					<div class="contact-box text-center white-bg">
						<i class="ti-map-alt theme-color"></i>
						<h5 class="uppercase mt-20">Address</h5>
						<p class="mt-20">#51/27 Swamy towers-1st Floor, 1st Main, RJ Garden, ORR, Marathahalli, Bangalore – 560037</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4">
					<div class="contact-box text-center white-bg">
						<i class="ti-mobile theme-color"></i>
						<h5 class="uppercase mt-20">Phone</h5>
						<p class="mt-20 mb-10"> (+91)91760 72251<br/><br/>&nbsp;</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4">
					<div class="contact-box text-center white-bg">
						<i class="ti-email theme-color"></i>
						<h5 class="uppercase mt-20">Email</h5>
						<p class="mt-20 mb-10">contact@ineuron.ai<br/><br/>&nbsp;</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 text-center">
				<p class="mt-50 mb-30">It would be great to hear from you! If you got any questions, please do not hesitate to send us a message. We are looking forward to hearing from you!<br/></p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div id="formmessage">Success/Error Message Goes Here</div>
				<form class="form-horizontal" id="contactform" role="form" method="post" action="php/contact-form.php">
					<div class="contact-form clearfix">
						<div class="section-field">
							<input id="name" type="text" placeholder="Name*" class="form-control"  name="name">
						</div> 
						<div class="section-field">
							<input type="email" placeholder="Email*" class="form-control" name="email">
						</div>
						<div class="section-field">
							<input type="text" placeholder="Phone*" class="form-control" name="phone">
						</div>
						<div class="section-field textarea">
							<textarea class="form-control input-message" placeholder="Comment*" rows="7" name="message"></textarea>
						</div>
						<div class="g-recaptcha section-field clearfix" data-sitekey="[Add your site key]"></div>
						<div class="section-field submit-button">
							<input type="hidden" name="action" value="sendEmail"/>
							<button id="submit" name="submit" type="submit" value="Send" class="button"> Send your message </button>
						</div>
					</div>
				</form>
			  <div id="ajaxloader" style="display:none"><img class="center-block mt-30 mb-30" src="images/pre-loader/loader-02.svg" alt=""></div> 
			</div>
		</div>
	</div>
</section>
<!--=================================
contact-->
 
 
 

<!--=================================
contact map -->
<section class="contact-map clearfix o-hidden">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-lg-12">
				<div class="map bg-overlay-black-20">
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d972.0350736447082!2d77.7016775274358!3d12.962873194033358!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x89fbcd434743b11b!2siNeuron.ai!5e0!3m2!1sen!2sin!4v1563128287106!5m2!1sen!2sin" style="border:0; width: 100%; height: 350px;"></iframe>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
contact map -->


 

<?php include('footer.php')  ?>

