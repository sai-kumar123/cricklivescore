
<!--=================================
 footer -->
 
<footer class="footer page-section-pt black-bg">
	<div class="container-fluid">
		<div class="row">
		
			
			
			<div class="col-lg-2 col-md-6 col-sm-6 xs-mb-30">
				<div class="footer-useful-link footer-hedding">
					<h6 class="text-white mb-30 mt-10 text-uppercase">Courses</h6>
					<ul>
						<li><a href="#">Data Science Masters</a></li>
						<li><a href="#">Data Analytics</a></li>
						<li><a href="#">Cloud Computing</a></li>
						<li><a href="#">Big Data</a></li>
						<li><a href="#">Fullstack</a></li>
						<li><a href="#">UX/UI Design</a></li>
						<li><a href="#">Devops</a></li>
					</ul>
				</div>
			</div>
			
			<div class="col-lg-4 col-md-6 col-sm-6 xs-mb-30">
				<h6 class="text-white mb-30 mt-10 text-uppercase">Contact us</h6>
				<div class="footer-Newsletter">
					<div id="mc_embed_signup_scroll">
						<form action="php/mailchimp-action.php" method="POST" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
							<div id="msg"> </div>                 
							<div id="mc_embed_signup_scroll_2">
								<div class="">
									<input id="mce-EMAIL" style="width:48%;float:left;margin-right:4%;" class="form-control" type="text" placeholder="Enter name" name="name" value="">
									<input id="mce-EMAIL" style="width:48%; float:left;" class="form-control" type="text" placeholder="Mobile number" name="name" value="">
								</div><br/>&nbsp;
							
								<input id="mce-EMAIL" class="form-control" type="text" placeholder="Email address" name="email1" value=""><br/>
								<textarea name="comment" class="form-control" name="message" rows="4" placeholder="Enter your message"></textarea>
							</div>
							<div id="mce-responses" class="clear">
								<div class="response" id="mce-error-response" style="display:none"></div>
								<div class="response" id="mce-success-response" style="display:none"></div>
							</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
							<div class="clear">
								<button type="submit" name="submitbtn" id="mc-embedded-subscribe" class="button border mt-20 form-button">  Submit </button>
							</div>
						</form>
					</div>
				</div>
			</div>
			
			<div class="col-lg-3 col-md-6 col-sm-6 xs-mb-30">
				<h6 class="text-white mb-30 mt-10 text-uppercase">Address</h6>
				<ul class="addresss-info"> 
					<li><i class="fa fa-map-marker"></i> <p> #51/27 Swamy towers-1st Floor, 1st Main, RJ Garden, ORR, Marathahalli, Bangalore – 560037</p> </li>
					<li><i class="fa fa-phone"></i> <a href="tel:7042791249"> <span>(+91)91760 72251</span> </a> </li>
					<li><i class="fa fa-envelope-o"></i>Email: contact@ineuron.ai</li><br/>
				</ul>
				<div class="social-icons color-hover">
					<p>Social Links</p>
					<ul> 
						<li class="social-facebook"><a href="https://www.facebook.com/Ineuronai-445526029601172/"><i class="fa fa-facebook"></i></a></li>
						<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i> </a></li>
						<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i> </a></li>
						<li class="social-youtube"><a href="#"><i class="fa fa-youtube"></i> </a></li>
					</ul>
				</div>
				&nbsp;
			</div>
			
			<div class="col-lg-3 col-md-6 col-sm-6 xs-mb-30">
				<h6 class="text-white mb-30 mt-10 text-uppercase">Locate Us </h6>
				<div class="map bg-overlay-black-30">
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d972.0350736447082!2d77.7016775274358!3d12.962873194033358!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x89fbcd434743b11b!2siNeuron.ai!5e0!3m2!1sen!2sin!4v1563128287106!5m2!1sen!2sin" style="border:0; width: 100%; height: 260px;"></iframe>
				</div>
			</div>
			
		</div>
		<div class="footer-widget mt-20">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 xs-mb-20">
					<p class="mt-15"> &copy;Copyright <span id="copyright"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> <a href="https://ineuron.ai/"> iNeuron.  </a>&nbsp; All Rights Reserved </p>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 text-right">
					<div class="footer-social mt-10">
						<ul class="list-inline text-right xs-text-left">
							<li><a href="terms-and-conditions.php">Terms &amp; Conditions </a> &nbsp;&nbsp;&nbsp;|</li>
							<li><a href="privacy-policy.php">Privacy Policy </a> </li>
						</ul>
					</div>
				</div>
			</div>    
		</div>
	</div>
</footer>

<!--=================================
 footer -->
 
 </div>

  

<div id="back-to-top"><a class="top arrow" href="#top"><i class="fa fa-angle-up"></i> <span>TOP</span></a></div>
 
<!--=================================
 jquery -->

<!-- jquery -->
<script type="text/javascript" src="js/jquery-1.12.4.min.js"></script>

<!-- plugins-jquery -->
<script type="text/javascript" src="js/plugins-jquery.js"></script>

<!-- plugin_path -->
<script type="text/javascript">var plugin_path = 'js/';</script>
 

<!-- custom -->
<script type="text/javascript" src="js/custom.js"></script>

<script src="js/particles.min.js"></script>
<script type="text/javascript" src="js/particles.js"></script>



<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d3756406d8083122839aa0d/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
 
 
 
 
</body>
</html>
