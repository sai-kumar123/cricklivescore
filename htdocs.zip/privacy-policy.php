
<?php include('header.php')  ?>


<!--=================================
page-title-->
<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">Privacy policy</h1>
				</div>
			</div>
		 </div>
	</div>
</div>
<!--=================================
page-title -->




<!--=================================
privacy policy-->
<section class="privacy-policy page-section-ptb section-bg">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="section-title ">
					<h4 class="title-effect">Privacy Policy</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<p>Quidem error quae illo excepturi nostrum blanditiis laboriosam magnam explicabo. lorem ipsum dolor sit amet, consectetur adipisicing elit. 
				<p>Eum nihil expedita dolorum odio dolorem, explicabo rem illum magni perferendis. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem error quae illo excepturi nostrum blanditiis laboriosam magnam explicabo. Molestias, eum nihil expedita dolorum odio dolorem, explicabo rem illum magni perferendis.</p>
				<p>Laboriosam magnam explicabo lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem error quae illo excepturi nostrum blanditiis. Molestias, eum nihil expedita dolorum odio dolorem, explicabo rem illum magni perferendis.</p>
				<h6 class="mt-30 theme-color">Personal Information</h6>
				<ul class="list list-unstyled">
					<li> <i class="fa fa-angle-right"></i> Amet consectetur lorem ipsum dolor sit  </li>
					<li> <i class="fa fa-angle-right"></i> Quidem error quae illo excepturi nostrum blanditiis laboriosam </li>
					<li> <i class="fa fa-angle-right"></i> Molestias, eum nihil expedita dolorum odio dolorem</li>
					<li> <i class="fa fa-angle-right"></i> Eum nihil expedita dolorum odio dolorem</li>
					<li> <i class="fa fa-angle-right"></i> Explicabo rem illum magni perferendis</li>
				</ul>
				<p class="mt-15">Debitis nemo animi quia deleniti commodi nesciunt illo. Deserunt. lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, ex, quisquam. Nulla excepturi sint iusto incidunt sed omnis expedita, commodi dolores. </p>
				<h6 class="mt-30 theme-color">Use of User Information.</h6>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, ex, quisquam. Nulla excepturi sint iusto incidunt sed omnis expedita, commodi dolores. Debitis nemo animi quia deleniti commodi nesciunt illo. Deserunt.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, ex, quisquam. Nulla excepturi sint iusto incidunt sed omnis expedita, commodi dolores. Debitis nemo animi quia deleniti commodi nesciunt illo. Deserunt.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, ex, quisquam. Nulla excepturi sint iusto incidunt sed omnis expedita, commodi dolores. Debitis nemo animi quia deleniti commodi nesciunt illo. Deserunt.</p>
				<h6 class="mt-30 theme-color">Disclosure of User Information.</h6>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem ullam nostrum dolor alias aspernatur nobis suscipit eaque cumque distinctio eos, beatae deserunt, nihil nam maiores vero, eius harum. Reprehenderit, aspernatur.<a href="#"> support@Webster.com</a> </p>
				<ul class="list list-unstyled">
					<li> <i class="fa fa-angle-right"></i> Nulla excepturi sint iusto incidunt sed omnis expedita </li>
					<li> <i class="fa fa-angle-right"></i> Quidem error quae illo excepturi nostrum blanditiis laboriosam </li>
					<li> <i class="fa fa-angle-right"></i> Deserunt.Lorem ipsum dolor sit amet</li>
					<li> <i class="fa fa-angle-right"></i> Possimus, ex, quisquam. Nulla excepturi</li>
				</ul>
				<p class="mt-15 mb-0">Commodi nesciunt illo. Deserunt lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus, ex, quisquam. Nulla excepturi sint iusto incidunt sed omnis expedita, commodi dolores. Debitis nemo animi quia deleniti .<a href="#"> support@Webster.com</a></p>
			</div> 
		</div>
	</div>
</section>
<!--=================================
privacy policy-->
  


<?php include('footer.php')  ?>