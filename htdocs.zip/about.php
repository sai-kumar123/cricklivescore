<?php include('header.php')  ?>



<!--=================================
page-title-->

<div class="top-banner">
	<!-- particles.js container --> 
	<div id="particles-js"></div>
	<div class="container">
		<div class="row"> 
			<div class="col-lg-12"> 
				<div class="section-title text-center">
					<h1 style="margin-top:120px;color:#ffffff;">About</h1>
				</div>
			</div>
		 </div>
	</div>
</div>

<!--=================================
page-title -->







<!--=================================
about -->
<section class="our-activities section-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-7 col-md-7 sm-mb-30"> 
				<div class="section-title mb-20">
					<h6>Who we are and what we do </h6>
					<h2>Get to know us better. </h2>
					<p>We truly care about our students. We are dedicated to providing you with the best experience possible.</p>
				</div>
				<p>We at iNeuron academy are a group of highly qualified and professional team of about thirty who are involved in Web development, we have set out to provide you with the best of class in the mentioned service as well as other miscellaneous web based solutions with high levels of expertise. 
					State of the art technology, unique design at an affordable price and timely delivery of projects that we undertake has assured us of a competitive position in this technology-driven industry. </p>	   
			</div>
			<div class="col-lg-5 col-md-5 sm-mt-50"> 
				<div class="accordion plus-icon shadow">
					<div class="acd-group acd-active">
						<a href="#" class="acd-heading">01. Vision</a>
						<div class="acd-des">iNeuron Academy is a renowned training center which offers comprehensive training programs on Artificial Inteligence with a strong base of real-time trainers with proven expertise in varied technology domains.
						We follow a customized curriculum to fulfill the career objectives of the students as well as professionals.
						</div>
					</div>
					<div class="acd-group">
						<a href="#" class="acd-heading">02. Mission </a>
						<div class="acd-des">We are passionate about creating opportunities through lifelong learning, to provide students with professional, 
						practical and positive learning experiences so they become competent, valuable professionals, 
						and to maximise their career opportunities and academic pathways. 
						We help to enrich student’s life experience through community connections by gaining practical work experience in Australia.</div>
					</div>
				</div>
			</div>      
		</div>
	</div>
</section>
<!--=================================
about -->





<!--=================================
Highlights -->
<section class="our-history white-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-10 col-md-10 col-md-offset-1">
				<div class="section-title text-center">
					<h2 class="title-effect">Our Highlights</h2>
					<p>iNeuron Academy - A pioneer in the education</p>
				</div>      
			</div>
		</div>
		<div class="row">
			<div class="col-lg-10 col-md-10 col-md-offset-1">
				<div class="timeline-dots"></div>
				<ul class="timeline">
					<li>
						<div class="timeline-badge"><p class="theme-color">01. Real time projects</p></div>
						<div class="timeline-panel">
							<div class="timeline-heading">
								<h5 class="timeline-title text-muted">Quis neque Suspendisse in orci enim.</h5>
							</div>
							<div class="timeline-body">
								<p>Dignissimos excepturi tempore iste, iusto sed sit delectus ratione laudantium, laboriosam quaerat eius odit explicabo necessitatibus, ipsum incidunt voluptas.</p>
							</div>
						</div>
					</li>
					<li class="timeline-inverted">
						<div class="timeline-badge"><p class="theme-color">02. Placement Assistance</p></div>
						<div class="timeline-panel">
							<div class="timeline-heading">
								<h5 class="timeline-title text-muted">Proin gravida nibh vel velit auctor aliquet. </h5>
							</div>
							<div class="timeline-body">
								<p>Iusto sed sit delectus ratione laudantium, laboriosam quaerat eius odit explicabo necessitatibus, ipsum incidunt voluptas dignissimos excepturi tempore iste. </p>
							</div>
						</div>
					</li>
					<li>
						<div class="timeline-badge"><p class="theme-color">03. Mock Interviews</p></div>
						<div class="timeline-panel">
							<div class="timeline-heading">
								<h5 class="timeline-title text-muted">Fermentum feugiat velit mauris egestas quam</h5>
							</div>
							<div class="timeline-body">
								<p>Incidunt voluptas dignissimos excepturi tempore iste iusto sed sit delectus ratione laudantium, laboriosam quaerat eius odit explicabo necessitatibus, ipsum. </p>
							</div>
						</div>
					</li>
					<li class="timeline-inverted">
						<div class="timeline-badge"><p class="theme-color">04. Robust Infrastructure</p></div>
						<div class="timeline-panel">
							<div class="timeline-heading">
								<h5 class="timeline-title text-muted">Aenean sollicitudin, lorem quis bibendum auctor</h5>
							</div>
							<div class="timeline-body">
								<p>Laboriosam quaerat eius odit explicabo necessitatibus, ipsum incidunt voluptas dignissimos excepturi tempore iste iusto sed sit delectus ratione laudantium.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="timeline-badge"><p class="theme-color">05. Experienced Instructors</p></div>
						<div class="timeline-panel">
							<div class="timeline-heading">
								<h5 class="timeline-title">Nullam ac urna eu felis dapibus condimentu</h5>
							</div>
							<div class="timeline-body">
								<p>Voluptas dignissimos excepturi tempore iste iusto sed sit delectus ratione laudantium laboriosam quaerat eius odit explicabo necessitatibus, ipsum incidunt. </p>
							</div>
						</div>
					</li>
					<li class="timeline-arrow"><i class="fa fa-chevron-down"></i></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!--=================================
Highlights -->




<!--=================================
our team -->
<section class="section-bg page-section-pb">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-title text-center mt-60">
					<h6>Meet our Superheros </h6>
					<h2 class="title-effect">Our creative team</h2>
					<p>Take your career to a new level with the iNeuron.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3 xs-mb-30">
				<div class="white-bg team team-hover team-border">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team1.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info mb-10"> 
							<h6><a href="#"> Sudhanshu Kumar</a></h6>
							<span>CEO(iNeuron)</span>
						</div>
						<div class="social-icons color clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 xs-mb-30">
				<div class="white-bg team team-hover team-border">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team2.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info mb-10"> 
							<h6><a href="#"> Krish Naik</a></h6>
							<span>Data Scientist(Panasonic)</span>
						</div>
						<div class="social-icons color clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-3 xs-mb-30">
				<div class="white-bg team team-hover team-border">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team3.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info mb-10"> 
							<h6><a href="#"> MD Mahabub Ansari</a></h6>
							<span>Data Scientist(eBest Mobile)</span>
						</div>
						<div class="social-icons color clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>  
			<div class="col-lg-3 col-md-3 col-sm-3 xs-mb-30">
				<div class="white-bg team team-hover team-border">
					<div class="team-photo">
						<img class="img-responsive center-block" src="img/team4.png" alt=""> 
					</div>    
					<div class="team-description"> 
						<div class="team-info mb-10"> 
							<h6><a href="#"> Khushboo Gupta</a></h6>
							<span>Data Scientist(E&Y, IIT Bombay)</span>
						</div>
						<div class="social-icons color clearfix">
							<ul>
								<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li class="social-linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
our team-->




<!--=================================
counter-->
<section class="page-section-pb text-center">
	<div class="container">
		<div class="row mt-60">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xx-12 sm-mb-30">       
				<div class="counter big-counter">
					<span class="timer" data-to="4000" data-speed="3000">4000</span>
					<label>STUDENTS TRAINED</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xx-12 sm-mb-30">
				<div class="counter big-counter">
					<span class="timer" data-to="300" data-speed="3000">300</span>
					<label>PROJECTS</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xx-12 xs-mb-30">
				<div class="counter big-counter">
					<span class="timer" data-to="3300" data-speed="3000">3300</span>
					<label>STUDENTS PLACED</label>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xx-12">
				<div class="counter big-counter">
					<span class="timer" data-to="5525" data-speed="3000">5525</span>
					<label>HAPPY CLIENTS</label>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
counter-->
 

 
<!--=================================
Alumni reviews -->
<section class="page-section-ptb section-bg">
	<div class="container">
		<div class="row">
		 <div class="col-lg-12 col-md-12">
			 <div class="section-title text-center">
				<h6>Have a look at our </h6>
				<h2 class="title-effect">Alumni Reviews</h2>
			  </div>
		   </div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="owl-carousel" data-nav-dots="true" data-items="2" data-md-items="2" data-sm-items="2" data-xs-items="1" data-xx-items="1">
					<div class="item">
						<div class="testimonial light">
							<div class="testimonial-avatar"> <img alt="" src="img/review1.jpg"> </div>
							<div class="testimonial-info"> It was a very good experience interacting with Sudhanshu in data science, he has a different way of explaining the things which will make anyone understand the topics deeper and he makes our basics very clear, I highly recommend Sudhanshu </div>
							<div class="author-info"> <strong>Suhas Es - <span>Facebook user</span></strong> </div>
						</div>
					</div>
					<div class="item">
						<div class="testimonial light">
							<div class="testimonial-avatar"> <img alt="" src="img/review2.jpg"> </div>
							<div class="testimonial-info"> It was great experience from our trainer Sudhanshu Kumar, who didn't focused only on explaining the theoretical portion which we can get it from various other mediums, instead he focused more on real time examples .</div>
							<div class="author-info"> <strong>Ruchi Kumari - <span>Facebook user</span></strong> </div>
						</div>
					</div>
					<div class="item">
						<div class="testimonial light">
							<div class="testimonial-avatar"> <img alt="" src="img/review3.jpg"> </div>
								<div class="testimonial-info"> I took Data science training from Sudhanshu.it was really good. my mentor was Sudhanshu Kumar he has a very good exposure and deep knowledge about the content. I would highly recommend Sudhanshu Kumar.</div>
							<div class="author-info"> <strong>Manas Ranjan - <span>Facebook user</span></strong> </div>
						</div>
					</div>
				</div>
			</div>  
		</div>
	</div>
</section>   
<!--=================================
Alumni reviews -->


<!--=================================
clients-->
<section class="white-bg page-section-ptb">
	<div class="container">
		<div class="row">
			<div class="col-lg-10 col-md-10 col-md-offset-1">
				<div class="section-title text-center">
					<h2 class="title-effect">Our Students Are Working In</h2>
				</div>      
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="clients-list">
					<div class="owl-carousel" data-nav-dots="false" data-items="5" data-md-items="4" data-sm-items="3" data-xs-items="2" data-xx-items="1">
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client1.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client2.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client3.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client4.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client5.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client6.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client7.png" alt="">
						</div>
						<div class="item"> 
							<img class="img-responsive center-block" src="img/client8.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--=================================
clients-->




<?php include('footer.php')  ?>